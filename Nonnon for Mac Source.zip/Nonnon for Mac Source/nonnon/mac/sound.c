// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_SOUND
#define _H_NONNON_MAC_SOUND




#import <AVFoundation/AVFoundation.h>




#include "../neutral/posix.c"




#define n_mac_sound_wav_init( wav_name ) n_mac_sound_init( wav_name, @"wav" )

AVAudioPlayer*
n_mac_sound_init( NSString *resource_name, NSString *ext )
{

	// [!] : resource_name
	//
	//	[ how to register ]
	//
	//		DnD to left side of Xcode
	//
	//	[ pitfalls ]
	//
	//		resource_name needs no extension
	//		for example : "mew.wav" => "mew" and "wav"


	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:resource_name ofType:ext];
//NSLog( @"%@", path );

	NSURL    *url  = [NSURL fileURLWithPath:path];
//NSLog( @"%@", url );

	return [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
}

void
n_mac_sound_loop_count( AVAudioPlayer *player, int value )
{

	// [!] : -1 for value : infinite loop playback

	player.numberOfLoops = value;


	return;
}

void
n_mac_sound_rewind( AVAudioPlayer *player )
{

	player.currentTime = 0;


	return;
}

#define n_mac_sound_play(  player ) [player  play]
#define n_mac_sound_stop(  player ) [player  stop]
#define n_mac_sound_pause( player ) [player pause]




// [!] : if you want more speed like games, use this

// [!] : this layer cannot play loop playback

// [x] : Monterey : "throwing -10878" is logged : maybe bug
// [x] : Sonoma   : "skipping cycle due to overload"

static AVAudioEngine *n_mac_sound_engine = NULL;

typedef struct {

	AVAudioFile          *file;

	AVAudioPlayerNode    *player;
	AVAudioMixerNode     *mixer;

	AVAudioUnitReverb    *reverb;
	AVAudioUnitDelay     *delay;

} n_mac_sound2;

void
n_mac_sound2_init( n_mac_sound2 *p, NSString *resource_name, NSString *ext )
{

	if ( n_mac_sound_engine == NULL )
	{
		n_mac_sound_engine = [[AVAudioEngine alloc] init];
	}


	NSBundle    *main = [NSBundle mainBundle];
	NSString    *path = [main pathForResource:resource_name ofType:ext];
	NSURL       *url  = [NSURL fileURLWithPath:path];
	AVAudioFile *file = [[AVAudioFile alloc] initForReading:url error:nil];

	p->file = file;


	p->player = [[AVAudioPlayerNode alloc] init];
	p->mixer  = [[AVAudioMixerNode  alloc] init];

	[n_mac_sound_engine attachNode:p->player];
	[n_mac_sound_engine attachNode:p->mixer ];

	[n_mac_sound_engine connect:p->player to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer  to:n_mac_sound_engine.mainMixerNode format:nil];


	// [!] : crash : when not connected

	[n_mac_sound_engine startAndReturnError:NULL];
	[n_mac_sound_engine prepare];


	return;
}

n_mac_sound2*
n_mac_sound2_init2( NSString *resource_name, NSString *ext )
{

	// [!] : for compatibility with n_mac_sound_init()

	n_mac_sound2 *ret = n_memory_new( sizeof( n_mac_sound2 ) );

	n_mac_sound2_init( ret, resource_name, ext );


	return ret;
}

void
n_mac_sound2_stop( n_mac_sound2 *p )
{
//NSLog( @"n_mac_sound2_stop" );


	[p->player stop];


	return;
}

void
n_mac_sound2_play( n_mac_sound2 *p )
{
//NSLog( @"n_mac_sound2_play" );


	// [x] : LM2    : slowdown
	// [x] : Typing : delay

	//if ( n_mac_sound_engine.running ) { n_mac_sound2_stop( p ); }


	// [Needed] : do every time

	[p->player scheduleFile:p->file
	                 atTime:nil
	      completionHandler:nil
	];


	[p->player play];


	return;
}




void
n_mac_sound2_effect_init( n_mac_sound2 *p, NSString *resource_name, NSString *ext )
{

	if ( n_mac_sound_engine == NULL )
	{
		n_mac_sound_engine = [[AVAudioEngine alloc] init];
	}


	NSBundle    *main = [NSBundle mainBundle];
	NSString    *path = [main pathForResource:resource_name ofType:ext];
	NSURL       *url  = [NSURL fileURLWithPath:path];
	AVAudioFile *file = [[AVAudioFile alloc] initForReading:url error:nil];

	p->file = file;


	p->player = [[AVAudioPlayerNode alloc] init];
	p->mixer  = [[AVAudioMixerNode  alloc] init];
	p->delay  = [[AVAudioUnitDelay  alloc] init];
	p->reverb = [[AVAudioUnitReverb alloc] init];

	[n_mac_sound_engine attachNode:p->player];
	[n_mac_sound_engine attachNode:p->mixer ];
	[n_mac_sound_engine attachNode:p->reverb];
	[n_mac_sound_engine attachNode:p->delay];

	[n_mac_sound_engine connect:p->player to:p->reverb                        format:nil];
	[n_mac_sound_engine connect:p->reverb to:p->delay                         format:nil];
	[n_mac_sound_engine connect:p->delay  to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer  to:n_mac_sound_engine.mainMixerNode format:nil];


	[n_mac_sound_engine startAndReturnError:NULL];
	[n_mac_sound_engine prepare];


	return;
}

n_mac_sound2*
n_mac_sound2_effect_init2( NSString *resource_name, NSString *ext )
{

	// [!] : for compatibility with n_mac_sound_init()

	n_mac_sound2 *ret = n_memory_new( sizeof( n_mac_sound2 ) );

	n_mac_sound2_effect_init( ret, resource_name, ext );


	return ret;
}

void
n_mac_sound2_effect_set( n_mac_sound2 *p, float pan, float wetdry, NSTimeInterval time, float feedback )
{

	[p->mixer setPan:pan]; 

	p->reverb.wetDryMix = wetdry;

	[p->delay setDelayTime:    time];
	[p->delay setFeedback :feedback];


	[n_mac_sound_engine connect:p->player to:p->reverb                        format:nil];
	[n_mac_sound_engine connect:p->reverb to:p->delay                         format:nil];
	[n_mac_sound_engine connect:p->delay  to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer  to:n_mac_sound_engine.mainMixerNode format:nil];


	return;
}




typedef struct {

	AVAudioPCMBuffer     *buffer;

	AVAudioPlayerNode    *player;
	AVAudioMixerNode     *mixer;

} n_mac_sound3;

// internal
void
n_mac_sound3_connect( n_mac_sound3 *p )
{

	[n_mac_sound_engine connect:p->player to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer  to:n_mac_sound_engine.mainMixerNode format:nil];


	return;
}

void
n_mac_sound3_init( n_mac_sound3 *p, NSString *resource_name, NSString *ext )
{

	if ( n_mac_sound_engine == NULL )
	{
		n_mac_sound_engine = [[AVAudioEngine alloc] init];
	}


	NSBundle    *main = [NSBundle mainBundle];
	NSString    *path = [main pathForResource:resource_name ofType:ext];
	NSURL       *url  = [NSURL fileURLWithPath:path];
	AVAudioFile *file = [[AVAudioFile alloc] initForReading:url error:nil];

	AVAudioFormat     *audioFormat = file.processingFormat;
	AVAudioFrameCount  length      = (AVAudioFrameCount) file.length;

	p->buffer = [[AVAudioPCMBuffer alloc] initWithPCMFormat:audioFormat frameCapacity:length];
	[file readIntoBuffer:p->buffer error:nil];


	p->player = [[AVAudioPlayerNode alloc] init];
	p->mixer  = [[AVAudioMixerNode  alloc] init];

	[n_mac_sound_engine attachNode:p->player];
	[n_mac_sound_engine attachNode:p->mixer ];

	n_mac_sound3_connect( p );


	[n_mac_sound_engine startAndReturnError:NULL];
	[n_mac_sound_engine prepare];


	return;
}

void
n_mac_sound3_stop( n_mac_sound3 *p )
{
//NSLog( @"n_mac_sound3_stop" );


	[p->player stop];


	return;
}

void
n_mac_sound3_play( n_mac_sound3 *p )
{
//NSLog( @"n_mac_sound3_play" );


	// [Needed] : do every time

	[p->player scheduleBuffer:p->buffer
	                   atTime:nil
	                  options:AVAudioPlayerNodeBufferLoops
	        completionHandler:nil
	];


	[p->player play];


	return;
}




// [!] : use for BGM, infinite loop is implemented

typedef struct {

	AVPlayerItem   *item;
	AVQueuePlayer  *queue;
	AVPlayerLooper *looper;

} n_mac_sound4;

n_mac_sound4*
n_mac_sound4_init( NSString *resource_name, NSString *ext, int64_t fr, int64_t to )
{

	n_mac_sound4 *ret = n_memory_new( sizeof( n_mac_sound4 ) );

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:resource_name ofType:ext];
	NSURL    *url  = [NSURL fileURLWithPath:path];
//NSLog( @"%@", path );
//NSLog( @"%@", url );

	ret->item   = [AVPlayerItem playerItemWithURL:url];
	ret->queue  = [AVQueuePlayer queuePlayerWithItems:@[ret->item]];

	CMTime f;
	if ( fr == -1 )
	{
		f = kCMTimeZero;
	} else {
		f = CMTimeMake( fr, 1000 );
	}

	CMTime t;
	if ( to == -1 )
	{
		t = kCMTimePositiveInfinity;
	} else {
		t = CMTimeMake( to, 1000 );
	}

	CMTimeRange r = CMTimeRangeMake( f, t );

 	ret->looper = [AVPlayerLooper playerLooperWithPlayer:ret->queue templateItem:ret->item timeRange:r];

	//ret->looper = [AVPlayerLooper playerLooperWithPlayer:ret->queue templateItem:ret->item];


	return ret;
}

void
n_mac_sound4_play( n_mac_sound4 *p )
{

	[p->queue play];

	return;
}

void
n_mac_sound4_stop( n_mac_sound4 *p )
{

	[p->queue pause];

	return;
}

void
n_mac_sound4_rewind( n_mac_sound4 *p )
{

	[p->queue seekToTime:kCMTimeZero];

	return;
}

void
n_mac_sound4_volume( n_mac_sound4 *p, CGFloat zero_one )
{

	[p->queue setVolume:zero_one];

	return;
}


#endif // _H_NONNON_MAC_SOUND


